USE [FomyDB]
GO

INSERT INTO [dbo].[Usuario]
           ([Email]
           ,[Nome]
           ,[Senha]
           ,[IdNivel]
           ,[Experiencia]
           ,[Foto]
           ,[Moedas]
           ,[DataCadastro])
     VALUES
           ('pedrinho@gmail.com','pedro","pedorfutebol2010' ,0 ,0,'/photos/038295325.jpg',0,GETDATE())
GO

